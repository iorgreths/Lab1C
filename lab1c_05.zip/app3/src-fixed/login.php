<html>

	<head>

		<title>A4 Test/login</title>

	</head>

	<body>
		<div>
			Willkommen, bitte geben Sie Ihren Benutzernamen ein:
		</div>
		<form action="check.php" method="post">
			<input type="text" name="username">
			<input type="submit" value="senden">
		</form>
	</body>
</html>
